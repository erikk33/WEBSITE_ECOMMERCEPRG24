# particles.js bubble animation edit

A Pen created on CodePen.io. Original URL: [https://codepen.io/CalebLinden/pen/vaQJKd](https://codepen.io/CalebLinden/pen/vaQJKd).

